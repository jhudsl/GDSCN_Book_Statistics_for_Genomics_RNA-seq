# (APPENDIX) Appendix {-}

# Help

We welcome any and all questions at our [Discourse Channel](https://help.anvilproject.org/).

If you have feedback on the activity (Found a typo? Have a suggestion or idea?) please [submit an issue on our GitHub repository](https://github.com/jhudsl/GDSCN_Book_Statistics_for_Genomics_RNA-seq/issues/new). You will need to make a GitHub account if you haven't done so yet.
